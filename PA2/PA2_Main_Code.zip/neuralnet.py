import numpy as np
import util
from copy import deepcopy

def xprint(*args):
    pass
    # print(" ".join(map(str,args)))

def lprint(*args):
  pass
  # print(" ".join(map(str,args)))

class Activation():
    """
    The class implements different types of activation functions for
    your neural network layers.

    """

    def __init__(self, activation_type = "sigmoid"):
        """
        TODO in case you want to add variables here
        Initialize activation type and placeholders here.
        """
        if activation_type not in ["sigmoid", "tanh", "ReLU","output"]:   #output can be used for the final layer. Feel free to use/remove it
            raise NotImplementedError(f"{activation_type} is not implemented.")

        # Type of non-linear activation.
        self.activation_type = activation_type

        # Placeholder for input. This can be used for computing gradients.
        self.x = None

    def __call__(self, z):
        """
        This method allows your instances to be callable.
        """
        return self.forward(z)

    def forward(self, z):
        """
        Compute the forward pass.
        """
        xprint("Activation Type: ", self.activation_type)
        if self.activation_type == "sigmoid":
            return self.sigmoid(z)

        elif self.activation_type == "tanh":
            return self.tanh(z)

        elif self.activation_type == "ReLU":
            return self.ReLU(z)

        elif self.activation_type == "output":
            # xprint(z.shape)
            # xprint(self.output(z).shape)
            return self.output(z)

    def backward(self, z):
        """
        Compute the backward pass.
        """
        # xprint("act type bckwd", self.activation_type)
        if self.activation_type == "sigmoid":
            return self.grad_sigmoid(z)

        elif self.activation_type == "tanh":
            return self.grad_tanh(z)

        elif self.activation_type == "ReLU":
            return self.grad_ReLU(z)

        elif self.activation_type == "output":
            return self.grad_output(z)


    def sigmoid(self, x):
        """
        TODO: Implement the sigmoid activation here.
        """
        return 1/(1+np.exp(-x))

    def tanh(self, x):
        """
        TODO: Implement tanh here.
        """
        return np.tanh(x)

    def ReLU(self, x):
        """
        TODO: Implement ReLU here.
        """
        return np.maximum(0,x)

    def output(self, x):
        """
        TODO: Implement softmax function here.
        Remember to take care of the overflow condition.
        """
        return np.exp(x)/np.exp(x).sum(axis=1, keepdims = True)
        # return(np.exp(x - np.max(x)) / np.exp(x - np.max(x)).sum())


    def grad_sigmoid(self,x):
        """
        TODO: Compute the gradient for sigmoid here.
        """
        grad = self.sigmoid(x)
        return grad * (1 - grad)

    def grad_tanh(self,x):
        """
        TODO: Compute the gradient for tanh here.
        """
        grad = self.tanh(x)
        return 1 - grad**2

    def grad_ReLU(self,x):
        """
        TODO: Compute the gradient for ReLU here.
        """
        return np.where(x >= 0, 1, 0)

    def grad_output(self, x):
        """
        Deliberately returning 1 for output layer case since we don't multiply by any activation for final layer's delta. Feel free to use/disregard it
        """
        return 1


class Layer():
    """
    This class implements Fully Connected layers for your neural network.
    """
    # self.count = 0 
    def __init__(self, in_units, out_units, activation, weightType, layer_numb, wtwt):
        """
        TODO in case you want to add variables here
        Define the architecture and create placeholders.
        """

        
        self.w = None
        if (weightType == 'random'):
            np.random.seed(42)
            # self.w = 0.01 * np.random.random((in_units+1, out_units))
            self.w = wtwt * np.random.normal(0, 1.0/np.sqrt(in_units+1), size=(in_units + 1, out_units)) # Tricks of the trade
    
        # self.w = np.ones((in_units, out_units))

        self.x = None    # Save the input to forward in this
        self.a = None    #output without activation
        self.z = None    # Output After Activation
        self.activation = activation   #Activation function
        # self.b = np.zeros((1,out_units))

        self.dw = np.zeros(self.w.shape) 
        # self.db = 0  # Save the gradient w.r.t w in this. You can have bias in w itself or uncomment the next line and handle it separately
        #self.d_b = None  # Save the gradient w.r.t b in this
        self.layer_numb = layer_numb
        # xprint("Initialized Layer number", layer_numb, "with activation ", self.activation.activation_type)
        self.prevChange_x = 0
        

    def __call__(self, x):
        """
        Make layer callable.
        """
        return self.forward(x)

    def forward(self, prev):
        """
        TODO: Compute the forward pass (activation of the weighted input) through the layer here and return it.
        """
        xprint("In forward Layer:", self.layer_numb) 
        xprint(" input x ", prev.shape)
        xprint("weights w", self.w.shape)
        
        lprint("In forward Layer:", self.layer_numb) 
        
        # input
        self.x = deepcopy(prev) # input ## a[L]
        lprint(" input x ", self.x[0][:3])
        
        # weighted input + bias
        self.a = np.matmul(self.x,self.w) 
        xprint("weighted input a", self.a.shape)
        lprint("weighted input a", self.a[0][:3])

        # activated input
        self.z = self.activation(self.a) 
        xprint("activated(a) = z", self.z.shape)
        lprint("activated(a) = z", self.z[0][:3])

        # Padding for bias only for hidden layers
        if self.activation.activation_type != "output":
          self.z = util.append_bias(self.z)


        return self.z
        

    def backward(self, deltaCur, learning_rate, momentum_gamma, regularization, gradReqd=True):
        """
        TODO: Write the code for backward pass. This takes in gradient from its next layer as input and
        computes gradient for its weights and the delta to pass to its previous layers. gradReqd is used to specify whether to update the weights i.e. whether self.w should
        be updated after calculating self.dw
        The delta expression (that you prove in PA2 part1) for any layer consists of delta and weights from the next layer and derivative of the activation function
        of weighted inputs i.e. g'(a) of that layer. Hence deltaCur (the input parameter) will have to be multiplied with the derivative of the activation function of the weighted
        input of the current layer to actually get the delta for the current layer. Remember, this is just one way of interpreting it and you are free to interpret it any other way.
        Feel free to change the function signature if you think of an alternative way to implement the delta calculation or the backward pass.
        gradReqd=True means update self.w with self.dw. gradReqd=False can be helpful for Q-3b
        """ 
        
        xprint("In backward Layer:", self.layer_numb) 
        xprint("input deltaCurr", deltaCur.shape)
        xprint("weights w", self.w.shape)
        xprint("Activation type: ", self.activation.activation_type)
        lprint("In backward Layer:", self.layer_numb) 
        lprint("delta curr", deltaCur[0,:3])        
        
        # backward
        xprint("Backward")
        xprint("Step 1 newDelta = deltaPrev * De_avtivation(myOutput) = (d*z)",deltaCur.shape,self.z.shape)
        lprint("using this self.a", self.a[0][:3])
        # newdelta = deltaCur * self.activation.backward(self.z)
        newdelta = np.multiply(self.activation.backward(self.a), deltaCur) # Error hidden Part 2 complete


        xprint("Step 2(dw) myInput * newDelta", self.x.shape, newdelta.shape)
        lprint("using this self.x", self.x[0][:3])

        self.dw =  np.matmul(self.x.T,newdelta)

        # xprint("Step 3(db) sum(newDelta)", self.x.shape, newdelta.shape)
        # self.db = np.sum(newdelta, axis = 0, keepdims=True)

        xprint("Step 4 Calculate the next delta for the next/prev layer = newDelta * myWeights", newdelta.shape, self.w.shape)
        deltaNext = np.matmul(newdelta,self.w.T[:,1:]) # Error hidden Part 1

        
        
        xprint("returns deltaNext from step 4")
        if gradReqd == True:
          return deltaNext, self.dw 
        return deltaNext, 0

    def update_params(self, learning_rate, momentum_gamma, RegLambda, batchSize):
        # Update
        xprint("Update")       
        xprint("Updating my weigts")
        oldWtmp = deepcopy(self.w)

        self.dw = self.dw/batchSize

        # momentum
        if momentum_gamma == -1:
          self.w += learning_rate * self.dw
        else:
          change_x = (learning_rate * self.dw) + (momentum_gamma * self.prevChange_x)
          self.w += change_x
          
          self.prevChange_x = change_x

        # Regularizer
        self.w -= (learning_rate * RegLambda * oldWtmp) # Does learning rate comes here or nah??
        
        



class Neuralnetwork():
    """
    Create a Neural Network specified by the network configuration mentioned in the config yaml file.

    """

    def __init__(self, config):
        """
        TODO in case you want to add variables here
        Create the Neural Network using config. Feel free to add variables here as per need basis
        """
        # xprint("Initialized Init ")
        print(config)
        self.layers = []  # Store all layers in this list.
        self.num_layers = len(config['layer_specs']) - 1  # Set num layers here
        self.x = None  # Save the input to forward in this
        self.y = None        # For saving the output vector of the model
        self.targets = None  # For saving the targets
        self.deltaCur = 0 # Starting delta y-t
        self.learning_rate = config["learning_rate"]
        self.momentum_gamma = -1 
        if config["momentum"]:
          self.momentum_gamma = float(config["momentum_gamma"])
        self.regularization = float(config["L2_penalty"])
        
        # self.epsilon = 10**-2 # for part b

        self.bs = config["batch_size"] # batch size


        # Add layers specified by layer_specs.
        for i in range(self.num_layers):
            if i < self.num_layers - 1:
                self.layers.append(
                    Layer(config['layer_specs'][i], config['layer_specs'][i + 1], Activation(config['activation']),
                          config["weight_type"], i, config["weight_weight"]))
            elif i == self.num_layers - 1:
                self.layers.append(Layer(config['layer_specs'][i], config['layer_specs'][i + 1], Activation("output"),
                                         config["weight_type"], i, config["weight_weight"]))


    def setBatchSize(self,bs):
      self.bs = bs


    def __call__(self, x, targets=None):
        """

        Make NeuralNetwork callable.
        """
        self.x = x 
        self.targets = targets

        lprint("_____"*20)
        # Forward
        lprint("Forward Starts:")
        lprint("x shape before forward: " , x.shape)
        self.forward(x)
        lprint("x shape after forward: " , x.shape)
        lprint("Forward Ends:\n")
        
        lprint("_____"*20)
        # Backward
        lprint("Backward Starts:")
        
        self.backward()
        lprint("Backward Ends:\n")
        



        lprint("_____"*20)
        lprint("Updating Params")
        self.update_params()
        lprint("Updating done")

        # input()
        

    def forward(self, x, targets=None, numApproxFlag = False):
        """
        TODO: Compute forward pass through all the layers in the network and return the loss.
        If targets are provided, return loss and accuracy/number of correct predictions as well.
        """
        self.x = x 

        if targets is not None:
          self.targets = targets

        for i in range(self.num_layers):
          xprint("___"*8, "Layer Number", i)
          x = self.layers[i].forward(x)
          
        
        self.y = x # Storing answer of this forward

        if targets is not None:
          acc = util.calculateCorrect(self.y,targets) # returns accuracy
          if numApproxFlag == False:
            print("Accuracy: ",acc)
          
          loss = self.loss(self.y,targets) # returns loss

          if numApproxFlag == False:
            print("Loss: ",loss)
          return self.y, acc, loss
        
        return self.y

        # return x


    def loss(self, y, t):
        '''
        TODO: compute the categorical cross-entropy loss and return it.
        '''
        # print(y.shape)
        # print(y)
        # print(np.sum(y),"\n",np.sum(t))
        # loss = -1/(20*len(y)) * np.sum(t*np.log(y))
        # return loss

        epsilon = 1e-10  # to avoid division by zero
        n = t.shape[0]
        lossi = -np.sum(t * np.log(np.maximum(y, epsilon)))
        lossi /= n

        # tL = 0
        # if self.regularization != 0:
        #   for i in range(self.num_layers-1,-1,-1):
        #     tL += (self.regularization / 2) * (np.linalg.norm(self.layers[i].w)**2)

        # return lossi+tl

        return lossi


    def backward(self, gradReqd=False):
        '''
        TODO: Implement backpropagation here by calling backward method of Layers class.
        Call backward methods of individual layers.
        '''

        xprint("targets: ", self.targets.shape)
        xprint("y: ", self.y.shape)

        self.deltaCur = self.targets - self.y # t-y
        # self.deltaCur = self.y - self.targets # y-t
        xprint("deltaCurr init", self.deltaCur.shape)

        grads = []
        for i in range(self.num_layers-1,-1,-1):
          xprint("___"*8, "Layer Number", i)
          self.deltaCur, tmp = self.layers[i].backward(self.deltaCur, self.learning_rate, self.momentum_gamma, self.regularization, gradReqd)
          grads.append(tmp)

        if gradReqd == True:
          return grads


          
        
          # if gradReqd == True:
          #   yield tmp
    
    def update_params(self):
        for i in range(self.num_layers-1,-1,-1):
          xprint("___"*8, "Layer Number", i)
          self.layers[i].update_params(self.learning_rate, self.momentum_gamma, self.regularization, self.bs)


    def saveWts(self):
      wts = []
      for i in range(self.num_layers-1,-1,-1):
        wts.append(self.layers[i].w)
      return wts

    def loadWts(self, wts): 
      # TODO Test this function, maybe wts will be sent reversed
      for i in range(self.num_layers-1, -1, -1):
        self.layers[i].w = wts[i]
      print("Successfully Loaded Weights")


