configYamlPath = "./configs/"  # Change it according to the directory of the platform on which the code is being run

datasetDir="./data/"
cifar100_directory= "cifar-100-python"

saveLocation="./plots/"