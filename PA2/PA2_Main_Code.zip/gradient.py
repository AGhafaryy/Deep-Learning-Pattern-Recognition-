import numpy as np
from neuralnet import Neuralnetwork
import pandas as pd
import util
import pickle


def check_grad(model, images, labels, epsilon, wt_id):
    """
    TODO
        Checks if gradients computed numerically are within O(epsilon**2)

        args:
            model
            x_train: Small subset of the original train dataset
            y_train: Corresponding target labels of x_train

        Prints gradient difference of values calculated via numerical approximation and backprop implementation
    """
    biass = []
    wtss = []
    for layerNo in range(len(model.layers)):
        # BIAS
        j = 0
        model.layers[layerNo].w[wt_id, j] += epsilon
        _, _, L1 = model.forward(images, labels, True)

        model.layers[layerNo].w[wt_id, j] -= 2 * epsilon
        _, _, L2 = model.forward(images, labels, True)

        model.layers[layerNo].w[wt_id, j] += epsilon
        biass.append((L2 - L1) / (2 * epsilon))

        # Weights
        for j in range(2, 4):
            model.layers[layerNo].w[wt_id, j] += epsilon
            _, _, L1 = model.forward(images, labels, True)

            model.layers[layerNo].w[wt_id, j] -= 2 * epsilon
            _, _, L2 = model.forward(images, labels, True)

            model.layers[layerNo].w[wt_id, j] += epsilon

            wtss.append((L2 - L1) / (2 * epsilon))

    return wtss, biass


def check_approx(model, approxes, wt_id):
    wtss = []
    biass = []
    for layerNo in range(len(model.layers)):
        # BIAS
        j = 0
        biass.append(approxes[layerNo][wt_id][j])

        # Weights
        for j in range(2, 4):
            wtss.append(approxes[layerNo][wt_id][j])

    return wtss, biass


def checkGradient(x_train, y_train, config):
    subsetSize = 10  # Feel free to change this
    sample_idx = np.random.randint(0, len(x_train), subsetSize)
    # sample_idx = [10]
    x_train_sample, y_train_sample = x_train[sample_idx], y_train[sample_idx]

    # x_train_sample = util.normalize_data(x_train_sample)
    # config["layer_specs"] = [3072, 123, 123, 20]
    model = Neuralnetwork(config)
    epsilon = 10 ** -2
    wt_id = 110

    # with open("bstWeights.pickle", "rb") as f:
    #     bestWts = pickle.load(f)
    #
    # model.loadWts(bestWts)

    # Numerical
    wtss, biass = check_grad(model, x_train_sample, y_train_sample, epsilon, wt_id)

    # Approxes
    approxes = model.backward(True)
    approxes = approxes[::-1]

    Awtss, Abiass = check_approx(model, approxes, wt_id)
    Awtss, Abiass = list(np.array(Awtss)/subsetSize), list(np.array(Abiass)/subsetSize)

    # print("BIAS")
    df = pd.DataFrame(columns=['Type of Weight', 'Layer Number', "Wts Number", "Numerical", "Approx", "Difference"])
    for i in range(len(model.layers)):
        lno = i
        numi = biass[lno]
        appri = Abiass[lno]
        diff = abs(numi - appri)
        # print("Layer No.", lno)
        # print("Numerical:", numi)
        # print("Approx", appri)
        # print("Difference", diff)

        df = df.append(
            {'Type of Weight': "Bias", 'Layer Number': lno, "Wts Number": -1, "Numerical": numi, "Approx": appri,
             "Difference": diff}, ignore_index=True)

    # print("Wts")
    for i in range(len(model.layers)):
        lno = i
        # print("Layer No.", lno)


        for j in range(i*2, (i*2) + 2):
            wtNo = j
            numi = wtss[wtNo]
            appri = Awtss[lno]
            diff = abs(numi - appri)
            # print("Weight No.", wtNo)
            # print("Numerical:", numi)
            # print("Approx", appri)
            # print("Difference", diff)
            df = df.append(
                {'Type of Weight': "Weights", 'Layer Number': lno, "Wts Number": (wtNo%2)+1, "Numerical": numi, "Approx": appri,
                 "Difference": diff}, ignore_index=True)

    print(df)
